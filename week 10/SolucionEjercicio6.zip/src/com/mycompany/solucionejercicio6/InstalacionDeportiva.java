
package com.mycompany.solucionejercicio6;

public interface InstalacionDeportiva {
    int getTipoDeInstalacion();
}
