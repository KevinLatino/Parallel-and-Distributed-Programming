
package com.mycompany.solucionejercicio6;

public interface Edificio {
    double getSuperficieEdificio();
}
